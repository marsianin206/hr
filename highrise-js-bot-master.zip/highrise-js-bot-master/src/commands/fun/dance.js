module.exports = {
  name: 'dance', // Имя команды
  description: 'Выполняет случайный танец или эмоцию на игроке.', // Описание команды
  usage: 'dance [@username | all]', // Пример использования команды
  aliases: ['emote', 'e', 'd'], // Список алиасов команды
  cooldown: 5, // Задержка перед повторным использованием команды (в секундах)
  async execute(bot, user, args) {
    try {
      // Список доступных эмоций
      const emotes = [
        'idle-dance-casual',
        'emote-float',
        'emote-lust',
        'emote-teleporting',
        'idle-singing',
        'dance-tiktok10',
        'emote-pose1',
        'dance-tiktok9',
        'emote-cute',
        'dance-tiktok8',
        'dance-tiktok2',
        'emote-cutey',
        'emote-model',
        'emote-superpose',
        'emote-pose5',
        'emote-pose3',
        'emote-pose1',
        'emote-pose8',
        'emote-pose7'
      ];

      // Выбираем случайную эмоцию
      const randomEmote = emotes[Math.floor(Math.random() * emotes.length)];
      const option = args[0]; // Получаем первый аргумент команды

      // Если аргумент не указан, бот выполняет эмоцию на себе
      if (!option) {
        return await bot.player.emote(user.id, randomEmote);
      }

      // Если указан пользователь через '@' и у вызывающего есть права модератора
      if (option.startsWith('@') && bot.perms.moderators.includes(user.id)) {
        const userName = option.substring(1); // Убираем '@' из имени пользователя
        const userId = await bot.room.players.cache.id(userName); // Получаем ID пользователя
        if (!userId) {
          return bot.whisper.send(user.id, `Пользователь ${option} не находится в комнате.`);
        }
        return await bot.player.emote(userId, randomEmote); // Выполняем эмоцию на указанном пользователе
      }

      // Если указан 'all' и у вызывающего есть права модератора
      if (option === 'all' && bot.perms.moderators.includes(user.id)) {
        const players = await bot.room.players.cache.get(); // Получаем список всех игроков в комнате
        const numPlayers = players.usernames.length; // Количество игроков

        // Если игроков больше 10, разбиваем их на группы
        if (numPlayers > 10) {
          const numGroups = Math.ceil(numPlayers / 5); // Количество групп (по 5 игроков в каждой)
          const groups = [];

          // Разделяем игроков на группы
          for (let i = 0; i < numGroups; i++) {
            const start = i * 5;
            const end = Math.min(start + 5, numPlayers);
            groups.push(players.usernames.slice(start, end));
          }

          // Каждая группа выполняет эмоцию с задержкой
          let delay = 0;
          groups.forEach(async (group) => {
            setTimeout(async () => {
              for (const username of group) {
                if (username !== bot.config.botName) { // Проверяем, что это не бот
                  const playerId = await bot.room.players.cache.id(username);
                  if (playerId !== undefined) {
                    await bot.player.emote(playerId, randomEmote); // Выполняем эмоцию
                  }
                }
              }
            }, delay * 5000); // Задержка между группами
            delay++;
          });
        } else {
          // Если игроков 10 или меньше, выполняем эмоцию на всех
          players.usernames.forEach(async (username) => {
            if (username !== bot.config.botName) { // Проверяем, что это не бот
              const playerId = await bot.room.players.cache.id(username);
              await bot.player.emote(playerId, randomEmote); // Выполняем эмоцию
            }
          });
        }
      }
    } catch (error) {
      console.error(error); // Логируем ошибку в консоль
      bot.whisper.send(user.id, `Что-то пошло не так. Пожалуйста, свяжитесь с @iHsein.`); // Отправляем сообщение об ошибке
    }
  },
};