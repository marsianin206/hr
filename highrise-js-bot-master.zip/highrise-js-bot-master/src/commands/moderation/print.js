module.exports = {
  name: 'print', // Имя команды
  description: 'Вывести данные о пользователе', // Описание команды
  usage: 'print <user>', // Пример использования команды
  permissions: ['print'], // Требуемые разрешения для использования команды
  cooldown: 5, // Задержка перед повторным использованием команды (в секундах)
  async execute(bot, user, args) {
    try {
      const prefix = bot.config.prefix; // Префикс команд из конфигурации

      // Получаем имя пользователя из аргументов
      const username = args[0];
      if (!username) {
        return bot.whisper.send(user.id, `Неверное имя пользователя. Пример: ${prefix}print @user`);
      }

      // Убираем символ '@' из имени пользователя
      const target = username.replace('@', '');
      if (!target) {
        return bot.whisper.send(user.id, `Неверное имя пользователя. Пример: ${prefix}print @user`);
      }

      // Получаем ID пользователя
      const userId = await bot.room.players.cache.id(target);
      if (!userId) {
        return bot.whisper.send(user.id, `Пользователь ${target} не находится в комнате.`);
      }

      // Получаем позицию пользователя
      const userPosition = await bot.room.players.cache.position(userId);

      let msg;

      // Проверяем, содержит ли позиция координаты (x, y, z, facing)
      if ('x' in userPosition && 'y' in userPosition && 'z' in userPosition && 'facing' in userPosition) {
        msg = `[PRINT]: User ID: ${userId} User Name: ${target} User Position: ${userPosition.x}, ${userPosition.y}, ${userPosition.z}, ${userPosition.facing}`;
      } 
      // Проверяем, содержит ли позиция данные об объекте (entity_id, anchor_ix)
      else if ('entity_id' in userPosition && 'anchor_ix' in userPosition) {
        msg = `[PRINT]: User ID: ${userId} User Name: ${target} User Position: ${userPosition.entity_id}, ${userPosition.anchor_ix}`;
      }

      // Логируем сообщение в консоль
      console.log(`${msg}`.yellow);
      // Отправляем сообщение в чат
      bot.message.send(msg);

    } catch (error) {
      // Отправляем сообщение об ошибке пользователю
      bot.whisper.send(user.id, `Что-то пошло не так, пожалуйста, свяжитесь с @iHsein`);
      // Логируем ошибку в консоль
      console.error(`Ошибка в команде 'print': ${error.message}`);
    }
  },
};
