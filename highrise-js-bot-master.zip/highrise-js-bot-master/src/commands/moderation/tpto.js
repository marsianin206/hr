module.exports = {
  name: 'tpto', // Имя команды
  description: 'Телепортироваться к игроку', // Описание команды
  usage: 'tpto <user>', // Пример использования команды
  aliases: ['follow', 'stalk'], // Список алиасов команды
  permissions: ['teleport'], // Требуемые разрешения для использования команды
  cooldown: 5, // Задержка перед повторным использованием команды (в секундах)

  async execute(bot, user, args) {
    try {
      const prefix = bot.config.prefix; // Префикс команд из конфигурации

      // Получаем имя пользователя из аргументов
      const username = args[0];
      if (!username) {
        return bot.whisper.send(user.id, `Неверное имя пользователя. Пример: ${prefix}tpto @user`);
      }

      // Убираем символ '@' из имени пользователя
      const target = username.replace('@', '');
      if (!target) {
        return bot.whisper.send(user.id, `Неверное имя пользователя. Пример: ${prefix}tpto @user`);
      }

      // Получаем ID пользователя
      const userId = await bot.room.players.cache.id(target);
      if (!userId) {
        return bot.whisper.send(user.id, `Пользователь ${target} не находится в комнате.`);
      }

      // Получаем текущую позицию целевого пользователя
      const targetLocation = await bot.room.players.cache.position(userId);

      // Телепортируем вызывающего команду к целевому пользователю
      return bot.player.teleport(user.id, targetLocation.x, targetLocation.y, targetLocation.z, targetLocation.facing);

    } catch (error) {
      // Отправляем сообщение об ошибке пользователю
      bot.whisper.send(user.id, `Что-то пошло не так, пожалуйста, свяжитесь с @iHsein`);
      // Логируем ошибку в консоль
      console.error(`Ошибка в команде 'tpto': ${error.message}`);
    }
  },
};
