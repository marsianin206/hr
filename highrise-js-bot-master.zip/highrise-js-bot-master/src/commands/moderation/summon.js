module.exports = {
  name: 'summon', // Имя команды
  description: 'Призвать игрока к себе', // Описание команды
  usage: 'summon <user>', // Пример использования команды
  aliases: ['call', 'tptome', 'recall', 'c'], // Список алиасов команды
  permissions: ['teleport'], // Требуемые разрешения для использования команды
  cooldown: 5, // Задержка перед повторным использованием команды (в секундах)
  async execute(bot, user, args) {
    try {
      const prefix = bot.config.prefix; // Префикс команд из конфигурации

      // Получаем имя пользователя из аргументов
      const username = args[0];
      if (!username) {
        return bot.whisper.send(user.id, `Неверное имя пользователя. Пример: ${prefix}summon @user`);
      }

      // Убираем символ '@' из имени пользователя
      const target = username.replace('@', '');
      if (!target) {
        return bot.whisper.send(user.id, `Неверное имя пользователя. Пример: ${prefix}summon @user`);
      }

      // Получаем ID пользователя
      const userId = await bot.room.players.cache.id(target);
      if (!userId) {
        return bot.whisper.send(user.id, `Пользователь ${target} не находится в комнате.`);
      }

      // Получаем текущую позицию вызывающего команду
      const myPosition = await bot.room.players.cache.position(user.id);

      // Проверяем, находится ли вызывающий команду на объекте (entity)
      if ('entity_id' in myPosition) {
        return bot.whisper.send(user.id, `Извините, вы не можете призвать игрока, находясь на объекте.`);
      }

      // Телепортируем указанного пользователя к вызывающему
      bot.player.teleport(userId, myPosition.x, myPosition.y, myPosition.z, myPosition.facing);

    } catch (error) {
      // Отправляем сообщение об ошибке пользователю
      bot.whisper.send(user.id, `Что-то пошло не так, пожалуйста, свяжитесь с @iHsein`);
      // Логируем ошибку в консоль
      console.error(`Ошибка в команде 'summon': ${error.message}`);
    }
  },
};
