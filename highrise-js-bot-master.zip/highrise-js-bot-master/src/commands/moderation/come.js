module.exports = {
  name: 'come', // Имя команды
  description: 'Призвать бота к себе', // Описание команды
  usage: 'come', // Пример использования команды
  aliases: ['follow-me'], // Список алиасов команды
  developer: true, // Команда доступна только разработчикам
  cooldown: 5, // Задержка перед повторным использованием команды (в секундах)
  async execute(bot, user, args) {
    try {
      // Получаем текущую позицию пользователя
      const myPosition = await bot.room.players.cache.position(user.id);

      // Проверяем, находится ли пользователь на объекте (entity)
      if ('entity_id' in myPosition) {
        return bot.whisper.send(user.id, `Извините, вы не можете призвать бота, находясь на объекте.`);
      }

      // Перемещаем бота к позиции пользователя
      bot.move.walk(myPosition.x, myPosition.y, myPosition.z, myPosition.facing);

    } catch (error) {
      // Отправляем сообщение об ошибке пользователю
      bot.whisper.send(user.id, `Произошла ошибка, пожалуйста, свяжитесь с @iHsein.`);
      // Логируем ошибку в консоль
      console.error(`Ошибка в команде 'come': ${error.message}`);
    }
  },
};
