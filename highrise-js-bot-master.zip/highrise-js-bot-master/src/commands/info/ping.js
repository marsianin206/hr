module.exports = {
  name: 'ping', // Имя команды
  description: 'Получить пинг бота', // Описание команды
  usage: 'ping', // Пример использования команды
  aliases: ['latency'], // Список алиасов команды
  cooldown: 10, // Задержка перед повторным использованием команды (в секундах)
  async execute(bot, user, args) {
    // Получаем текущий пинг бота
    const latency = await bot.ping.get();

    // Отправляем сообщение с пингом в чат
    bot.message.send(`🤖 Пинг бота: ${latency}мс`);
  },
};
