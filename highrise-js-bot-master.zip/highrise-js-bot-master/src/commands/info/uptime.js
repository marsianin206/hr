const { getUptime } = require("../../utils/utils"); 
// Импортируем функцию для получения времени работы бота

module.exports = {
  name: 'uptime', // Имя команды
  description: 'Получить время работы бота.', // Описание команды
  usage: 'uptime', // Пример использования команды
  execute(bot, user, args) {
    // Отправляем сообщение с временем работы бота
    bot.message.send(getUptime());
  },
};