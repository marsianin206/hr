const { formatNumber } = require("../../utils/utils"); 
// Импортируем функцию для форматирования чисел

module.exports = {
  name: 'wallet', // Имя команды
  description: 'Получить содержимое кошелька бота', // Описание команды
  usage: 'wallet', // Пример использования команды
  async execute(bot, user, args) {
    try {
      // Получаем количество средств в кошельке бота
      const amount = await bot.wallet.amount();
      // Получаем тип валюты в кошельке бота
      const type = await bot.wallet.type();

      // Проверяем, что данные корректны
      if (amount === undefined || type === undefined) {
        return bot.message.send('Не удалось получить данные кошелька. Пожалуйста, попробуйте позже.');
      }

      // Отправляем сообщение с информацией о кошельке
      bot.message.send(`У меня сейчас ${formatNumber(amount)} ${type}`);
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка при получении данных кошелька: ${error.message}`);
      // Отправляем сообщение об ошибке пользователю
      bot.message.send('Произошла ошибка при получении данных кошелька. Пожалуйста, свяжитесь с администратором.');
    }
  },
};