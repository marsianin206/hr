const reloadCommand = {
  name: 'reload', // Имя команды
  description: 'Перезагружает указанную команду', // Описание команды
  usage: '!reload <category> <command name>', // Пример использования команды
  developer: true, // Команда доступна только разработчикам
  execute(bot, user, args, commands) {
    try {
      // Получаем имя категории и команды из аргументов
      const categoryName = args[0]?.toLowerCase();
      const commandName = args[1]?.toLowerCase();

      // Проверяем, указаны ли оба аргумента
      if (!categoryName || !commandName) {
        return bot.whisper.send(
          user.id,
          `Неверные аргументы.\nПример: !reload <category> <commandName>`
        );
      }

      // Проверяем, существует ли команда
      const command = commands.get(commandName);
      if (!command) {
        return bot.whisper.send(user.id, `Команда "${commandName}" не найдена.`);
      }

      // Удаляем кешированную версию команды
      delete require.cache[
        require.resolve(`../../commands/${categoryName}/${command.name}.js`)
      ];

      // Загружаем обновленную версию команды
      const newCommand = require(`../../commands/${categoryName}/${command.name}.js`);

      // Обновляем команду в коллекции
      commands.set(newCommand.name, newCommand);

      // Отправляем сообщение об успешной перезагрузке
      bot.message.send(`Команда "${commandName}" была успешно перезагружена.`);
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в команде 'reload': ${error.message}`);
      // Отправляем сообщение об ошибке пользователю
      bot.whisper.send(user.id, `Произошла ошибка при перезагрузке команды.`);
    }
  },
};

module.exports = reloadCommand;
