const fs = require('fs');

const cooldowns = new Map(); // Карта для отслеживания задержек команд
const commands = new Map(); // Карта для хранения всех команд

console.log("[i] Highrise Command Handler:".blue);

// Чтение всех папок с командами
const commandFolders = fs.readdirSync('./src/commands');

for (const folder of commandFolders) {
  const commandFiles = fs.readdirSync(`./src/commands/${folder}`).filter((file) => file.endsWith('.js'));

  for (const file of commandFiles) {
    const command = require(`../commands/${folder}/${file}`);
    commands.set(command.name, command); // Добавляем команду в карту

    // Добавляем алиасы команды
    if (command.aliases) {
      for (const alias of command.aliases) {
        commands.set(alias, command);
      }
    }
    console.log(`Loading Highrise command ${file}`.green); // Логируем загрузку команды
  }
}

const commandHandler = (bot, user, message) => {
  const args = message.split(' '); // Разделяем сообщение на аргументы
  const commandName = args.shift().toLowerCase(); // Получаем имя команды

  const command = commands.get(commandName); // Ищем команду по имени

  if (!command) {
    return; // Если команда не найдена, ничего не делаем
  }

  // Проверка разрешений пользователя
  const permissions = require('../../config/json/permissions.json').permissions;
  const userPermissions = permissions.find(permission => permission.user_id === user.id);

  if (command.permissions && (!userPermissions || !userPermissions.permissions.some(p => command.permissions.includes(p)))) {
    return bot.whisper.send(user.id, `Извините, у вас нет прав для использования команды ${command.name}`);
  }

  // Проверка, является ли команда доступной только для владельцев
  if (command.developer && !bot.perms.owners.includes(user.id)) {
    return bot.whisper.send(user.id, `Извините, команда ${command.name} доступна только владельцам.`);
  }

  // Проверка, отключена ли команда
  if (command.disabled && !bot.perms.owners.includes(user.id)) {
    return bot.whisper.send(user.id, `Извините, команда ${command.name} в данный момент недоступна.`);
  }

  // Проверка задержек (cooldowns)
  const userId = user.id;
  if (!bot.perms.owners.includes(userId)) {
    if (!cooldowns.has(command.name)) {
      cooldowns.set(command.name, new Map());
    }
    const now = Date.now();
    const timestamps = cooldowns.get(command.name);
    const cooldownAmount = (command.cooldown || 0) * 1000;
    if (timestamps.has(userId)) {
      const expirationTime = timestamps.get(userId) + cooldownAmount;
      if (now < expirationTime) {
        const timeLeft = (expirationTime - now) / 1000;
        return bot.whisper.send(user.id, `Пожалуйста, подождите еще ${timeLeft.toFixed(1)} секунд перед повторным использованием команды ${command.name}`);
      }
    }
    timestamps.set(userId, now);
    setTimeout(() => timestamps.delete(userId), cooldownAmount);
  }

  // Выполнение команды
  try {
    command.execute(bot, user, args, commands);
  } catch (error) {
    console.error(`Ошибка при выполнении команды ${command.name}:`, error);
    bot.whisper.send(user.id, 'Произошла ошибка при выполнении команды.');
  }
};

module.exports = { commandHandler };
