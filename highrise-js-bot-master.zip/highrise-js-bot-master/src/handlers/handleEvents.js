const fs = require('fs');
const path = require('path');

module.exports = (bot) => {
  const eventsDir = path.join(__dirname, '../events'); // Путь к директории с событиями

  const events = [];
  try {
    // Читаем все файлы событий клиента из директории events/client
    fs.readdirSync(path.join(eventsDir, 'client')).forEach(file => {
      const eventPath = path.join(eventsDir, 'client', file);
      const event = require(eventPath); // Импортируем событие
      bot.on(event.name, (...args) => event.execute(bot, ...args)); // Привязываем событие к боту
      events.push({
        Event: file,
        Status: "✅" // Успешно загружено
      });
    });

    console.table(events, ["Event", "Status"]); // Выводим таблицу загруженных событий клиента
    console.info("\x1b[36m%s\x1b[0m", "Loaded Highrise Client Events.");
  } catch (error) {
    console.error("Ошибка при загрузке событий клиента:", error.message);
  }

  const serverEvents = [];
  try {
    // Читаем все файлы событий сервера из директории events/server
    fs.readdirSync(path.join(eventsDir, 'server')).forEach(file => {
      const eventPath = path.join(eventsDir, 'server', file);
      const event = require(eventPath); // Импортируем событие
      bot.on(event.name, (...args) => event.execute(bot, ...args)); // Привязываем событие к боту
      serverEvents.push({
        Event: file,
        Status: "✅" // Успешно загружено
      });
    });

    console.table(serverEvents, ["Event", "Status"]); // Выводим таблицу загруженных событий сервера
    console.info("\x1b[36m%s\x1b[0m", "Loaded Highrise Server Events.");
  } catch (error) {
    console.error("Ошибка при загрузке событий сервера:", error.message);
  }
};
