module.exports = {
  /**
   * Получает список игроков в комнате.
   * @param {object} bot - Экземпляр бота.
   * @returns {Promise<object[]>} - Промис, который возвращает массив объектов игроков.
   */
  getPlayersInRoom: async (bot) => {
    try {
      const results = await bot.room.players.fetch(); // Получаем список игроков
      return results;
    } catch (error) {
      console.error("Ошибка при получении списка игроков:", error.message);
      return [];
    }
  },

  /**
   * Вычисляет время работы бота.
   * @returns {string} - Отформатированная строка с временем работы.
   */
  getUptime: () => {
    const uptimeSeconds = process.uptime(); // Получаем время работы процесса в секундах
    const days = Math.floor(uptimeSeconds / (24 * 60 * 60)); // Вычисляем дни
    const hours = Math.floor((uptimeSeconds % (24 * 60 * 60)) / (60 * 60)); // Вычисляем часы
    const minutes = Math.floor((uptimeSeconds % (60 * 60)) / 60); // Вычисляем минуты
    const seconds = Math.floor(uptimeSeconds % 60); // Вычисляем секунды
    return `⏰ Я онлайн уже: ${days} дней, ${hours} часов, ${minutes} минут, ${seconds} секунд`;
  },
};
