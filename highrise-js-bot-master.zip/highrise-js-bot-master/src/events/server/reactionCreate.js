module.exports = {
  name: 'reactionCreate', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, sender, receiver, reaction) {
    try {
      // Логируем реакцию, если включено логирование
      if (bot.logs.reactions) {
        console.log(`${sender.username} отправил реакцию ${reaction} пользователю ${receiver.username}`);
      }

      // Проверяем, включена ли функция кика по реакции
      if (bot.settings.kickOnReact) {
        const IDS = bot.perms.moderators; // Получаем список модераторов
        // Если отправитель является модератором и реакция совпадает с заданной
        if (IDS.includes(sender.id) && reaction === bot.settings.reaction) {
          await bot.player.kick(receiver.id); // Кикаем получателя реакции
          console.log(`Пользователь ${receiver.username} был кикнут модератором ${sender.username} за реакцию ${reaction}`);
        }
      }
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'reactionCreate': ${error.message}`);
    }
  }
};
