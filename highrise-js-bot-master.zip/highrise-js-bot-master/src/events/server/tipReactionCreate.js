const { logTips } = require('../../assets/logs/logger');
// Импортируем функцию для логирования чаевых

module.exports = {
  name: 'tipReactionCreate', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, sender, receiver, item) {
    try {
      // Логируем чаевые, если включено логирование
      if (bot.logs.tips) {
        logTips(sender, receiver, item); // Логируем чаевые в файл
        console.log(`Чаевые от ${sender.username} для ${receiver.username}: ${item.amount} ${item.type}`); // Логируем в консоль
      }

      // Проверяем, включена ли функция танца на чаевые
      if (bot.settings.danceOnTip) {
        // Если получатель чаевых — бот
        if (receiver.id === bot.config.botId) {
          await bot.player.emote(sender.id, bot.settings.emoteId); // Бот выполняет эмоцию
          console.log(`Бот исполнил эмоцию "${bot.settings.emoteId}" для ${sender.username} в ответ на чаевые.`);
        }
      }
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'tipReactionCreate': ${error.message}`);
    }
  }
};
