module.exports = {
  name: 'emoteCreate', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, sender, receiver, emote) {
    try {
      // Проверяем, включено ли логирование эмоций
      if (bot.logs.emotes) {
        // Логируем информацию об эмоции в консоль
        console.log(`${sender.username} отправил эмоцию ${emote} пользователю ${receiver.username}`);
      }

      // Дополнительная обработка эмоций (если требуется)
      // Например, выполнение действий на основе типа эмоции
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'emoteCreate': ${error.message}`);
    }
  },
};
