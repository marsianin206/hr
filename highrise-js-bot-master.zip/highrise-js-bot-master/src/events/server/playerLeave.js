const { logLeave } = require("../../assets/logs/logger");
// Импортируем функцию для логирования выходов пользователей

module.exports = {
  name: 'playerLeave', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, user) {
    try {
      // Логируем выход пользователя, если включено логирование
      if (bot.logs.leave) {
        logLeave(user); // Логируем в файл
        console.log(`${user.username}(${user.id}) покинул комнату`); // Логируем в консоль
      }

      // Отправляем прощальное сообщение в чат
      const farewellMessage = `😢 ${user.username} покинул нас... Надеемся, ты скоро вернешься! 🌟`;
      bot.message.send(farewellMessage); // Отправляем сообщение в чат
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'playerLeave': ${error.message}`);
    }
  }
};
