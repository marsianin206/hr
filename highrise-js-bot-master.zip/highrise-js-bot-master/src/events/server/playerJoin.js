const { logJoin } = require("../../assets/logs/logger");
// Импортируем функцию для логирования входов пользователей

module.exports = {
  name: 'playerJoin', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, user) {
    try {
      // Логируем вход пользователя, если включено логирование
      if (bot.logs.join) {
        logJoin(user); // Логируем в файл
        console.log(`${user.username}(${user.id}) вошел в комнату`); // Логируем в консоль
      }

      // Отправляем крутое приветствие в чат
      const welcomeMessage = `🎉 Добро пожаловать, ${user.username}! 🎉\n` +
                             `Мы рады видеть тебя здесь! 🚀\n` +
                             `Наслаждайся временем в комнате и не забудь улыбнуться! 😊`;
      bot.message.send(welcomeMessage); // Отправляем сообщение в чат
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'playerJoin': ${error.message}`);
    }
  }
};
