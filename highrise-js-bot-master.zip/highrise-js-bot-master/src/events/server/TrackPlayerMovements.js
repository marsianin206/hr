module.exports = {
  name: 'TrackPlayerMovement', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, user, position) {
    // Проверяем, включено ли логирование перемещений
    if (bot.logs.movements) {
      // Если позиция содержит координаты (x, y, z, facing)
      if ('x' in position && 'y' in position && 'z' in position && 'facing' in position) {
        console.log(`${user.username} переместился на координаты: ${position.x}, ${position.y}, ${position.z}, ${position.facing}`);
      } 
      // Если позиция содержит данные об объекте (entity_id, anchor_ix)
      else if ('entity_id' in position && 'anchor_ix' in position) {
        console.log(`${user.username} переместился на объект: ${position.entity_id} с индексом ${position.anchor_ix}`);
      }
    }
  }
};