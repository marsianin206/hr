const { commandHandler } = require("../../handlers/handlePrefix");
// Импортируем обработчик команд с префиксом

const { logMessages } = require("../../assets/logs/logger");
// Импортируем функцию для логирования сообщений

module.exports = {
  name: "chatMessageCreate", // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, user, message) {
    try {
      const prefix = bot.config.prefix; // Получаем префикс команд из конфигурации

      // Логируем сообщение, если включено логирование
      if (bot.logs.messages) {
        console.log(`[${user.username}]: ${message}`); // Выводим сообщение в консоль
        logMessages(user, message); // Логируем сообщение в файл
      }

      // Проверяем, начинается ли сообщение с префикса
      if (message.startsWith(prefix)) {
        // Передаем обработку команды в commandHandler
        commandHandler(bot, user, message.slice(prefix.length));
      } else {
        return; // Если сообщение не является командой, ничего не делаем
      }
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'chatMessageCreate': ${error.message}`);
    }
  }
};
