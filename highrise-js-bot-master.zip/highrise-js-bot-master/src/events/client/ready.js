const { getPlayersInRoom } = require("../../utils/utils");
// Импортируем функцию для получения списка игроков в комнате

module.exports = {
  name: 'ready', // Имя события
  once: true, // Указывает, что событие будет вызвано только один раз
  async execute(bot, BotId, rateLimits, connectionId, sdkVersion) {
    try {
      // Телепортируем бота на заданные координаты из конфигурации
      bot.player.teleport(
        BotId,
        bot.config.coordinates.x,
        bot.config.coordinates.y,
        bot.config.coordinates.z,
        bot.config.coordinates.facing
      );

      // Если включено логирование события "ready"
      if (bot.logs.ready) {
        // Получаем список игроков в комнате
        const players = await getPlayersInRoom(bot);

        // Логируем информацию о готовности бота
        console.log(
          `${bot.config.botName} is now ready in ${bot.config.roomName} with ${players.length} players.\n` +
          `Bot ID: ${BotId}\nRate Limits: ${rateLimits.client}\nConnection ID: ${connectionId}`
          .green
        );
      }
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'ready': ${error.message}`);
    }
  }
};