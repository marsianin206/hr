const { commandHandler } = require("../../handlers/handlePrefix");
// Импортируем обработчик команд с префиксом

module.exports = {
  name: 'whisperMessageCreate', // Имя события
  once: false, // Указывает, что событие может вызываться несколько раз
  async execute(bot, user, message) {
    try {
      const prefix = bot.config.prefix; // Получаем префикс команд из конфигурации
      const moderators = bot.perms.moderators; // Получаем список модераторов

      // Логируем личное сообщение, если включено логирование
      if (bot.logs.whisper) {
        console.log(`(whisper)[${user.username}]: ${message}`); // Выводим сообщение в консоль
      }

      // Если сообщение начинается с '//' и отправитель является модератором
      if (message.startsWith('//') && moderators.includes(user.id)) {
        const args = message.split('//'); // Разделяем сообщение по '//'
        const text = args.join(" "); // Объединяем текст обратно
        bot.message.send(text); // Отправляем сообщение в чат
      } 
      // Если сообщение начинается с префикса команды
      else if (message.startsWith(prefix)) {
        commandHandler(bot, user, message.slice(prefix.length)); // Обрабатываем команду
      } 
      // Если сообщение не соответствует условиям, ничего не делаем
      else {
        return;
      }
    } catch (error) {
      // Логируем ошибку в консоль
      console.error(`Ошибка в событии 'whisperMessageCreate': ${error.message}`);
    }
  }
};