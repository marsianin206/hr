const fs = require("fs");
const path = require("path");

// Получаем текущую метку времени в формате UTC
const timestamp = new Date().toLocaleString('en-GB', { 
  timeZone: 'UTC', 
  day: '2-digit', 
  month: '2-digit', 
  year: 'numeric', 
  hour: '2-digit', 
  minute: '2-digit', 
  second: '2-digit' 
});

// Логирует сообщения пользователей
function logMessages(user, message) {
  const filePath = path.join(__dirname, "../../../lib/playerMessages.log");

  const playerName = user.username;
  const playerID = user.id;

  const logMessage = `[${playerName}](${playerID}): ${message} at: (${timestamp})\n`;

  fs.appendFile(filePath, logMessage, (err) => {
    if (err) {
      console.error(`Не удалось записать сообщение: ${err}`);
    }
  });
}

// Логирует входы пользователей в комнату
function logJoin(user) {
  const filePath = path.join(__dirname, "../../../lib/playerJoined.log");

  const playerName = user.username;
  const playerID = user.id;

  const logMessage = `[${playerName}](${playerID}): Joined the room at: (${timestamp})\n`;

  fs.appendFile(filePath, logMessage, (err) => {
    if (err) {
      console.error(`Не удалось записать вход: ${err}`);
    }
  });
}

// Логирует выходы пользователей из комнаты
function logLeave(user) {
  const filePath = path.join(__dirname, "../../../lib/playerLeft.log");

  const playerName = user.username;
  const playerID = user.id;

  const logMessage = `[${playerName}](${playerID}): Left the room at: (${timestamp})\n`;

  fs.appendFile(filePath, logMessage, (err) => {
    if (err) {
      console.error(`Не удалось записать выход: ${err}`);
    }
  });
}

// Логирует чаевые, отправленные пользователями
function logTips(sender, reciever, item) {
  const filePath = path.join(__dirname, "../../../lib/playerTips.log");

  const senderName = sender.username;
  const senderID = sender.id;

  const recieverName = reciever.username;
  const recieverID = reciever.id;

  const logMessage = `[${senderName}](${senderID}) tipped [${recieverName}](${recieverID}) ${item.amount} ${item.type} at ${timestamp}\n`;

  fs.appendFile(filePath, logMessage, (err) => {
    if (err) {
      console.error(`Не удалось записать чаевые: ${err}`);
    }
  });
}

// Экспортируем функции для использования в других модулях
module.exports = {
  logJoin,    // Логирование входов
  logLeave,   // Логирование выходов
  logMessages, // Логирование сообщений
  logTips     // Логирование чаевых
};